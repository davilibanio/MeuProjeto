import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

import strada from '../assets/strada.png';
import abarth from '../assets/abarth.png';
import newTucson from '../assets/newtucson.png';
import cross from '../assets/t-cross.png';
import broncosport from '../assets/broncosport.png';

export default BancoDados = [
    {id:0,  nome:"STRADA", descricao:" Versão : RANCH AT, Ar-condicionado automático digital, Wirelless charger,Câmbio Automatico, Airbags Laterais, Camera de ré, Capacidade de 600 Kg, Motores Firefly( Melhor consumo de combustivel, Gasolina, Ano:2022 " ,valor: 80.00, imagem: strada}, 
    {id:1,  nome:"PULSE ABARTH",descricao:"Versão: TURBO 270 FLEX AP, Câmera Traseira ,Faróis De Neblina Dianteiros, Freio De Estacionamento Eletrônico,Piloto Automático (cruise Control),Computador De Bordo,Direção Elétrica,Wireless Charger, Câmbio Automático De 6 Marchas, Ano:2023" ,valor: 100.00, imagem:abarth },
    {id:2,  nome:"NEW TUCSON",descricao:" Motor: 1,6 Gamma T-GDI (G4FJ),Gasolina, Tração:FWD (4x2) (Dianteira),Ar condicionado (Dual Zone ), Entrada para iPod/USB 2.0/Auxiliar, Faróis em LED com fita em LED, Teto solar panorâmico com sistema antiesmagamento,Airbags(condutor, passageiro e laterais),Retrovisores externos com comando elétrico, Câmera de ré ,Painel de bordo Super Vision 4.2.TFT LCD, Ano: 2021", valor: 70.00, imagem:newTucson},
    {id:3,  nome:"T-CROSS",descricao:"Versão: 200 TSI, Ano/Modelo 2023,Ar-condicionado com filtro de poeira e pólen,Controle eletrônico de estabilidade (ESC), controle de tração (ASR) e bloqueio eletrônico do diferencial (EDS),Indicador de controle da pressão dos pneus e sistema de frenagem automática pós-colisão (Post Collision Brake),Lanternas traseiras em LED,Motor TSI,Transmissão automática de 6 velocidades, Flex"  ,valor: 85.00, imagem:cross },
    {id:4,  nome:"Bronco Sport 2.0L EcoBoost",descricao:" Motor 2.0L EcoBoost (253cv / 380Nm),Transmissão Automática de 8 velocidades, Teto solar, Faróis full LED,Câmeras dianteira e traseira, Alerta de colisão com Assistente Autônomo de Frenagem e Detecção de Pedestres, Piloto automático Adaptativo com Stop & Go, Gasolina, Ano: 2022"  ,valor: 65.00 , imagem:broncosport },
]