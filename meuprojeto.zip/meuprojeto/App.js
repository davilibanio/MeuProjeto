import * as React from 'react';
import { Text, View, StyleSheet, FlatList, Image, Button, TouchableOpacity} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import  Disponiveis from './components/BancoDados';
import  Logo from './assets/logo.png';
import  Login from './assets/login.png';
import  senha from './assets/senha.png';
import  Codigo from './assets/codigo.png';





 function Opcoes(props){ 
    function Item({item}) {     
     
  return(    
    
      <TouchableOpacity onPress={()=>{props.navigation.navigate("Detalhes", {dados:item})}}>   
           <View>  </View>      

        <View style ={{flexDirection: "colum"}} style={styles.borda} >       
          <Text style={styles.text}>{item.nome} </Text>
          <View style={styles.borda1} style ={{flexDirection: "row"}}>           
            <Image style={styles.carros} source={item.imagem}/> 
          </View>      
          <Text style={styles.text2}>Valor dia: R${item.valor} </Text> 
        
        </View> 
    </TouchableOpacity>
    
   
  );
}
   function IrHome(){
     props.navigation.navigate("Inicio");
   }      
  return(
      <View style={styles.borda1}  >
          <Button title="Sair" onPress={IrHome}/> 
          <View style={{alignItems:"center"}}>
            <Text style={styles.text3} > Carros Disponiveis </Text> 
          </View>          
        <FlatList 
          data={Disponiveis} 
          renderItem={Item}      
      />
      
      </View>
  );
}



function Inicio(props){
  function IrLista(){
       props.navigation.navigate("Carros");
  }
  function Ircadastro(){
       props.navigation.navigate("Cadastrar");
  }
  function IrSenha(){
       props.navigation.navigate("Recuperar");
  }

    return(
      <View style={styles.borda} style={{flexDirection:'colum'}}>
        <View style={{alignItems:'center'}}> 
          
          <Image style={styles.icones2} source={Logo} />
          
        </View >
          <Image style={styles.icones1} source={Login}/>
          <Text>Login:</Text>
          <Image style={styles.icones1} source={senha}/>
          <Text>Senha:</Text>    
        <View >
          <Button title="entrar" onPress={IrLista}/>  
        </View>
        <Text> </Text>
        <View style={{justifyContent:'space-between',flexDirection:'row'}}>
          <Button title="Esqueci Minha senha" onPress={IrSenha}/> 
          <Button title="Cadastar"  onPress={Ircadastro}/> 
        </View>        
      </View>

    );

}

function Cadastro(props){
  function IrHome(){
     props.navigation.navigate("Inicio");
   }  
  return(
    <View style={styles.borda} >
      <View style={{alignItems:'center'}}>
        <Text style={styles.text}>Cadastro</Text> 
      </View>                
      <Text style={styles.text2}>Nome completo: </Text>
      <Text style={styles.text2}>Gênero: </Text>
      <Text style={styles.text2}>Data de nascimento: </Text>
      <Text style={styles.text2}>Cpf: </Text>
      <Text style={styles.text2}>Telefone: </Text>
      <Text style={styles.text2}>Email:</Text>
      <Text style={styles.text2}>Senha:</Text> 
      <Button title="Criar seu cadastro" onPress={IrHome}/>    
     </View>

  );

}

function RecuperarSenha(props){
  function IrHome(){
     props.navigation.navigate("Inicio");
   }    
   function IrEmail(){
     props.navigation.navigate("IrEmail");
   }  
    return(
      <View style={styles.borda}> 
        <Text style={styles.text}> Identifique-se para receber um e-mail com as instruções e o link para criar uma nova senha.
        </Text> 
        <Text> </Text>
        <Text style={styles.text2}>email:</Text>
        <Text> </Text>
        <Button title="enviar" onPress={IrEmail} /> 
        <Button title="cancelar"  onPress={IrHome}/> 
      </View>
    );
}


function NovaSenha(props){
  function IrHome(){
     props.navigation.navigate("Inicio");
   } 
    return(
      <View style={styles.borda}>
        <Text style={styles.text}> Email para alteração de senha enviado com sucesso!</Text>
        <Button title="Inicio" onPress={IrHome}/>
      </View>
    );
}


function FinalizarAluguel(props){
  function IrLista(){
     props.navigation.navigate("Carros");
   } 
   function IrCartao(){
     props.navigation.navigate("Cartao");
   } 
   function IrPix(){
     props.navigation.navigate("Pix");
   } 
   function IrEspecie(){
     props.navigation.navigate("Especie");
   } 
   function IrBoleto(){
     props.navigation.navigate("Boleto");
   } 

  return (
      <View style={styles.borda}>
        <View tyle={{alignItems:'center'}}>
        <Text style={styles.text}> Alugar </Text> 
        </View> 
        <View style={styles.borda1}> 
          <Text style={styles.text2}> Quantidade de dias: </Text>
          <Text style={styles.text2}> Total: </Text>
        </View> 
        <Text> </Text>
        <View> 
          <Text style={styles.text}>Forma de pagamento:</Text>
        </View>        
        <View>
          <Button title=" Cartao" onPress={IrCartao} /> 
          <Button title=" Pix" onPress={IrPix}/> 
          <Button title=" Especie(Na retirada)" onPress={IrEspecie}/> 
          <Button title="Boleto" onPress={IrBoleto}/>          
        </View> 
        <Button title="Cancelar" onPress={IrLista}/> 

           
        
      </View>
  );
}


function Cartao(props){
  function IrComprovante(){
     props.navigation.navigate("Comprovante");
   } 
   function IrFinalizar(){
     props.navigation.navigate("Finalizar");
   } 
  return(
    <View style={styles.borda}>
      <View tyle={{alignItems:'center'}} > 
        <Text style={styles.text} >Cartao </Text>
      </View> 
        <Text style={styles.text2}> Número do cartão:</Text>
        <Text style={styles.text2}> Nome Completo:</Text>
        <Text style={styles.text2}> Data de vencimento:</Text>
        <Text style={styles.text2}> Código de Segurança:</Text>
        <Text style={styles.text2}> CPF do titular:</Text> 
        <Button title="Finalizar" onPress={IrComprovante} />
      <Button title="Voltar" onPress={IrFinalizar}/>
      </View>
     
    
  );
}

function Pix(props){
   function IrComprovante(){
     props.navigation.navigate("Comprovante");
   } 
   function IrFinalizar(){
     props.navigation.navigate("Finalizar");
   } 

  return(
    <View style={styles.borda}> 
      <Text style={styles.text}> Pix </Text>
      <Text style={styles.text}> Código : 021e341413hiuhohoíhqtceftcec </Text>
      <Button title="Copiar Código" onPress={IrComprovante} />
      <Button title="Voltar" onPress={IrFinalizar}/>

    </View>
  );
}

function Especie(props){
   function IrComprovante(){
     props.navigation.navigate("Comprovante");
   } 
   function IrFinalizar(){
     props.navigation.navigate("Finalizar");
   } 
  return(
    <View style={styles.borda}> 
      <Text style={styles.text}>Especie </Text>
      <Text style={styles.text2}> Código de reserva gerado: 535364354364534</Text>
      <Button title="Finalizar" onPress={IrComprovante} />
      <Button title="Voltar" onPress={IrFinalizar}/>
    </View>
  );
}

function Boleto(props){
  function IrComprovante(){
     props.navigation.navigate("Comprovante");
   } 
   function IrFinalizar(){
     props.navigation.navigate("Finalizar");
   } 
  return(
    <View style={styles.borda}> 
      <Text style={styles.text}> Boleto</Text>
      <Image style={styles.carroos} source={Codigo}/>
      <Button title="Copiar Código de pagamento" onPress={IrComprovante} />
      <Button title="Voltar" onPress={IrFinalizar}/>
    </View>
  );
}

function Comprovante(props){
  function IrLista(){
       props.navigation.navigate("Carros");
  }
    return(
      <View style={styles.borda}> 
        <Text style={styles.text}> Comprovante de confirmação enviado para seu Email. Apresente no momento da retirada. 
        </Text>
        <Button title="Ok" onPress={IrLista} />

      </View>
    );
}




function Detalhes(props){
    function IrFinalizar(){
     props.navigation.navigate("Finalizar");
   } 
  const dados = props.route.params.dados
    return(
     
        <View style ={{flexDirection: "colum"}} style={styles.borda} >
       
          <Text style={styles.text}>{dados.nome} </Text> 

          <View style={styles.borda1} style ={{flexDirection: "row"}}> 
          <Text style={styles.text2}>{dados.descricao} </Text> 
          <Image style={styles.carro} source={dados.imagem}/> 
          </View>
      
          <Text style={styles.text2}> Valor dia: R${dados.valor} </Text>
          <Button title="Alugar" onPress={IrFinalizar} />          
        
        </View> 

    );

}



const Stack = createNativeStackNavigator();

export default function App(){
   return(
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name= "Inicio" component={Inicio} /> 
        <Stack.Screen name="Recuperar"  component={RecuperarSenha} />
        <Stack.Screen name="IrEmail"  component={NovaSenha} />
        <Stack.Screen name="Cadastrar"  component={Cadastro} />
        <Stack.Screen name= "Carros" component={Opcoes} />    
        <Stack.Screen name="Detalhes"  component={Detalhes} />
        <Stack.Screen name="Finalizar" component={FinalizarAluguel}/>
        <Stack.Screen name="Cartao" component={Cartao}/>
        <Stack.Screen name="Pix" component={Pix}/>
        <Stack.Screen name="Especie" component={Especie}/>                            
        <Stack.Screen name="Boleto" component={Boleto}/>
        <Stack.Screen name="Comprovante" component={Comprovante}/>

      </Stack.Navigator>    
    </NavigationContainer>
   );


}

const styles = StyleSheet.create({
  carros: { width: 180, height: 100 },
  carro: { width: 100, height: 70 },
  icones1: { width: 20, height: 20},
  icones2: { width: 250, height: 165 },  
  borda: {
    borderWidth: 2,
    borderRadius: 6,
    backgroundColor: '#7D6060',
    borderColor: '#4B3838',
  },
  imagem:{width: 10, height:10},
  text: { fontSize: 14, padding: 10, color:'#CAE44D' },
  text1: { fontSize: 14, padding: 10, color:'black' },  
  text2: { fontSize: 14, padding: 10, color:'white' },
  text3: { fontSize: 16, padding: 10, color:'white' },
   borda1: {
    borderWidth: 2,
    borderRadius: 6,
    backgroundColor: "#4B3838",
    borderColor: 'steelblue',
  },

});
